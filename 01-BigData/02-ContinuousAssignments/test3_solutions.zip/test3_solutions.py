from pyspark import SparkContext
from pyspark.sql import SparkSession

if __name__ == '__main__':

	# Definition of common variables
	filename = "file:///home/prac/test3/input/DataCoSupplyChainDataset.csv"
	file = open("/home/prac/test3/output/result.txt",'w')

	# Define SparkContext and SparkSession
	sc = SparkContext(appName = "Test3")
	spark = SparkSession(sc)


	###Q1 - Load data, convert to dataframe, apply appropriate column names and variable types

	# input defined_filename as the path
	SCData = sc.textFile(filename).map(lambda x: x.split(","))
	# convert into dataframe and convert numeric variables into integer or double
	df_sc = SCData.toDF(["Type", "CustomerCountry","CustomerFname","CustomerId","CustomerSegment","OrderItemProductPrice", "OrderItemQuantity","OrderItemTotal","ProductName"])
	df_sc = df_sc.withColumn("OrderItemProductPrice", df_sc["OrderItemProductPrice"].cast("double"))
	df_sc = df_sc.withColumn("OrderItemQuantity", df_sc["OrderItemQuantity"].cast("integer"))
	df_sc = df_sc.withColumn("OrderItemTotal", df_sc["OrderItemTotal"].cast("double"))
	
	###Q2 - Determine the proportion of each customer segment
	# Your solution goes here
	# convert to RDD and make reduce
	CustomerSegmentRDD = df_sc.rdd.map(lambda x : x[4])
	NumberPerCustomerSegment = df_sc.rdd.map(lambda x: (x[4],1)).reduceByKey(lambda v1, v2: v1 + v2)
	
	# calculating the total number and proportion for each	
	TotalSegment = df_sc.count()
	SegmentProportion = NumberPerCustomerSegment.map(lambda x: x[1] / TotalSegment * 100)
	
	# Printing the solution to the results.txt file
	file.write("Consumer = " + str(SegmentProportion.take(3)[0]) + "%, Corporate = " + str(SegmentProportion.take(3)[2]) + 
	"%, Home Office = " + str(SegmentProportion.take(3)[1]) + "%\n\n")


	###Q3 - Which three products had the least sales in revenue
	
	# Your solution goes here
	# calculating total revenue for each product
	TotalRevenuePerProduct = df_sc.rdd.map(lambda x : (x[-1], x[-2])).reduceByKey(lambda v1, v2: v1 + v2)
	# sort the total revenue
	TotalRevenuePerProductSorted = TotalRevenuePerProduct.sortBy(lambda x : x[1])
	# Printing the solution to the results.txt file
	file.write(TotalRevenuePerProductSorted.collect()[0][0] + " = $" + str(TotalRevenuePerProductSorted.collect()[0][1]) + 
		", " + TotalRevenuePerProductSorted.collect()[1][0] + " = $" + str(TotalRevenuePerProductSorted.collect()[1][1]) + 
		", " + TotalRevenuePerProductSorted.collect()[2][0] + " = $" + str(TotalRevenuePerProductSorted.collect()[2][1]) + "\n\n")


	###Q4 - For each transaction type, determine the average item cost before discount

	# Your solution goes here
	# calculate the total transaction cost and the amount of transaction quantity
	TotalTransactionCost = df_sc.rdd.map(lambda x : (x[0], x[-4] * x[-3])).reduceByKey(lambda v1, v2: v1 + v2)
	TotalTransactionQuantity = df_sc.rdd.map(lambda x : (x[0], x[-3])).reduceByKey(lambda v1, v2: v1 + v2)
	# Printing the solution to the results.txt file
	file.write("Average item cost: Transfer = $" + str(TotalTransactionCost.collect()[0][1] / TotalTransactionQuantity.collect()[0][1]) + 
		", Debit = $" + str(TotalTransactionCost.collect()[2][1] / TotalTransactionQuantity.collect()[2][1]) + 
		", Payment=$" + str(TotalTransactionCost.collect()[3][1] / TotalTransactionQuantity.collect()[3][1]) + 
		", Cash=$" + str(TotalTransactionCost.collect()[1][1] / TotalTransactionQuantity.collect()[1][1]) + "\n\n")


	###Q5 - What is the most regular customer first name in EE. UU.
	# Your solution goes here
	# make a data frame for all ee. uu.
	ee_uu_df = df_sc.filter(df_sc.CustomerCountry == "EE. UU.")
	# count customer id
	ee_uu_count = ee_uu_df.rdd.map(lambda x : (x[2] + "_" + x[3], 1)).reduceByKey(lambda v1, v2: v1 + v2)
	# sort it	
	ee_uu_count_sorted = ee_uu_count.sortBy(lambda x : x[1])
	# Printing the solution to the results.txt file
	file.write("Most regular customer name in EE. UU. is " + ee_uu_count_sorted.collect()[-1][0].split("_")[0] + 
		", who comes back " + str(ee_uu_count_sorted.collect()[-1][1]) + " times.")


	file.close()
