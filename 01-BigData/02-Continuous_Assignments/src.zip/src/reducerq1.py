#!/usr/bin/env python3

import sys

# initial values
temp_count = 0
temp_word_length = None

# input comes from STDIN
for line in sys.stdin:
	# remove leading and trailing whitespace
	line = line.strip()
	# parse the input we got from mapperq1.py
	word_length, count = line.split('\t', 1)
	
	# convert count (currently a string) to int
	# convert length (currently a string) to int
	try:
		count = int(count)
		word_length = int(word_length)
	except ValueError:
		continue
		
	# check if we get the same length as before
	# if yes, then increase counter;
	# if no, then output old results and start counting again
	
	if word_length == temp_word_length:
		temp_count = temp_count + count
	else:
		if temp_word_length != None:
			print('%s\t%s'% (temp_word_length, temp_count))
		temp_word_length = word_length
		temp_count = count
# output very last word in the list
print('%s\t%s'% (temp_word_length, temp_count))


