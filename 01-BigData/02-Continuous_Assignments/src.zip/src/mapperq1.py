#!/usr/bin/env python3

import sys

""" Code Document
1. read lines of the input text
2. remove leading and trailing whitespaces
3. split line of text into words
4. pass the lenth of words as output
"""


# input comes from STDIN
for line in sys.stdin:
	# remove leading and trailing whitespace
	line = line.strip()
	# split the line into words
	words = line.split()
	
	# increase counters
	for word in words:
		# write the results to STDOUT (standard output);
		# what we output here will be the input for the
		# Reduce step, i.e. the input for reducer.py
		# tab-delimited; the trivial word length count is 1
		print("%s\t%s" % (len(word), 1))
