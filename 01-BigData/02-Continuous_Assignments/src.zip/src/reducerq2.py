#!/usr/bin/env python3

import sys

# initial values
temp_count = 0
temp_word_first_letter = None

# input comes from STDIN
for line in sys.stdin:
	# remove leading and trailing whitespace
	line = line.strip()
	# parse the input we got from mapperq2.py
	word_first_letter, count = line.split('\t', 1)
	
	# convert count (currently a string) to int
	try:
		count = int(count)
	except ValueError:
		continue
		
	# check if we get the same word as before
	# if yes, then increase counter;
	# if no, then output old results and start counting again
	
	if word_first_letter == temp_word_first_letter:
		temp_count = temp_count + count
	else:
		if temp_word_first_letter != None:
			print('%s\t%s'% (temp_word_first_letter, temp_count))
		temp_word_first_letter = word_first_letter
		temp_count = count
# output very last word in the list
print('%s\t%s'% (temp_word_first_letter, temp_count))


