data.json: data.json is a data set, which contains information such as name, gender, position and salary

index.html: Use the pie chart to show the distribution of positions in the data set, and then use the bar chart to show the average salary of different genders (gender), Added mouseover and mouseout event listeners to each rectangle of the bar chart to change the color of the rectangle

How to Run: 
```
 http-server path_of_file_folder
```

Result: Visualization_Results.png

From the results of the visualization, there are four positions in total, and the number of employees in each position is the same, while the average salary of men is significantly higher than that of women.